using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Monster", menuName = "ScriptableObject/Monster")]
public class MonsterData : Entity
{
    
    public Sprite imageMonster;
}
