using UnityEngine;


public abstract class Entity: ScriptableObject
{

    [field: Header("Hp"),SerializeField] 
    protected internal int m_hp { get; internal set; }

    [field: Header("Defense"),SerializeField]
    protected int m_def { get; private set; }


    public virtual AbstractDataInstance Instance()
    {
        return new AbstractDataInstance(this);
    }

    public class AbstractDataInstance
    {

        public int m_hp;
        public int m_def;
        
        public AbstractDataInstance(Entity data)
        {
            m_hp = data.m_hp;
            m_def = data.m_def;
        }
    }
}