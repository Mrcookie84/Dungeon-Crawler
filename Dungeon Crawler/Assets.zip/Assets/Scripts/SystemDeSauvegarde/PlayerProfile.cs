namespace SystemDeSauvegarde
{
    [System.Serializable]
    public class PlayerProfile
    {

        public int PlayerLevel = 0;
        public int PlayerXP = 0;

    
    }
}
